---
layout: default
title: Home Made Goods
---

# Home Made Goods

## Contact me to order on WhatsApp / Kontak my om te bestel
[WhatsApp +27 65 677 2625](https://wa.me/27656772625)


## Click on this link to see what I sell / Klik hier om te sien wat ek verkoop
[Products Page](https://share.samsungcloud.com/sharedalbum/6JN1UIcZI4)

All orders must be picked up, we don’t deliver unless otherwise arranged. / Alle bestellings moet afgehaal word, ons lewer nie af nie, tensy anders gereël.

### Made by Electroboy2008
